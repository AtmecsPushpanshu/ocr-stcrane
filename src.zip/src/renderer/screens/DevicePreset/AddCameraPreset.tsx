import { Grid, Slider, Stack, Typography } from '@mui/material';
import {
  HeadText16,
  GridWithBorder,
  HeadTextCss,
  ImageFill,
  WithPadding,
} from '../../components/Styles';
import PTZbutton from '../../components/common/PTZbutton';
import containeImg from '../../assets/img/container.png';
import SelectField from '../../components/common/SelectField';

const AddCameraPreset = () => {
  return (
    <WithPadding>
      <Typography variant="h5" {...HeadTextCss}>
        Device Preset
      </Typography>
      <Grid container columns={18} sx={{ marginTop: '10px' }}>
        <Grid item xs={8}>
          <Stack>
            <GridWithBorder>
              <ImageFill src={containeImg} alt="img" />
            </GridWithBorder>
            <HeadText16 variant="h4" sx={{ marginTop: 2, marginBottom: '5px' }}>
              Captured Images
            </HeadText16>
            <GridWithBorder>
              <ImageFill src={containeImg} alt="img" />
            </GridWithBorder>
          </Stack>
        </Grid>
        <Grid item xs={10}>
          <Stack spacing={2} direction={'row'}>
            <WithPadding sx={{ paddingTop: 0 }}>
              <Stack flexDirection={'row'}>
                <GridWithBorder>
                  <WithPadding>
                    <HeadText16 sx={{ marginBottom: '4px' }}>
                      Pan / Tilt
                    </HeadText16>
                    <Stack spacing={2}>
                      <PTZbutton />
                      <SelectField
                        label="Pan Step"
                        direction={'row'}
                        sx={{
                          width: '89px',
                          height: '27px',
                        }}
                      />
                      <SelectField
                        label="Tilt Step"
                        direction={'row'}
                        sx={{
                          width: '89px',
                          height: '27px',
                        }}
                      />
                    </Stack>
                  </WithPadding>
                </GridWithBorder>
              </Stack>
            </WithPadding>
            <WithPadding sx={{ paddingTop: 0 }}>
              <Stack flexDirection={'row'}>
                <GridWithBorder>
                  <WithPadding>
                    <HeadText16 sx={{ marginBottom: '4px' }}>
                      Pan / Tilt
                    </HeadText16>
                    <Stack sx={{ height: '100%' }} spacing={1}>
                      <Slider
                        aria-label="Temperature"
                        orientation="vertical"
                        valueLabelDisplay="auto"
                        defaultValue={30}
                      />
                    </Stack>
                  </WithPadding>
                </GridWithBorder>
              </Stack>
            </WithPadding>
          </Stack>
        </Grid>
      </Grid>
    </WithPadding>
  );
};

export default AddCameraPreset;
