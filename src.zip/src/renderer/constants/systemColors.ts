export const SystemColors = {
  link: {
    icons: {
      active: '#24558D',
      inactive: '#ABA7AF',
    },
  },
};
